# 283. E-Commerce Buyurtmalar Monitoringi va Logistika Boshqaruvi

## Tavsif
**E-Commerce Buyurtmalar Monitoringi va Logistika Boshqaruvi** — Dashboard toifasiga mansub, FrontCraft Pro platformasining professional darajadagi interaktiv frontend loyihasidir. Loyiha asinxron ma'lumotlar bilan ishlash, SVG ma'lumotlar vizualizatsiyasi, Observer arxitekturasidagi reaktiv State boshqaruvi va to'liq moslashuvchan (Responsive) interfeysni o'z ichiga oladi.

## Asosiy Imkoniyatlar
- **Yangi tushgan buyurtmalar, qadoqlash va kuryerga topshirish oqimi**
- **Kuryerlar bo'yicha kunlik yetkazib berish unumdorligi ko'rsatkichi**
- **Mijoz manzili, to'lov turi va buyurtma tafsilotlari modali**
- **Reaktiv Store**: Observer and Pub/Sub patternlari orqali markazlashtirilgan holat boshqaruvi.
- **Dinamik SVG Grafiki**: Haqiqiy matematik koordinatalar asosida chiziluvchi dinamik ustunli diagramma.
- **Form Validatsiyasi**: Xatoliklarni real vaqt rejimida aniqlovchi xavfsiz forma boshqaruvi.
- **CSV Eksport**: Kiritilgan barcha ma'lumotlarni bir bosishda fayl ko'rinishida eksport qilish.
- **Xotira (LocalStorage)**: Foydalanuvchi ma'lumotlari va tanlangan tema brauzerda doimiy saqlanadi.

## Texnologiyalar
- HTML5
- CSS3
- JavaScript
- Order Tracking
- Courier Dispatch
- Charts

## Ishga tushirish
Hech qanday murakkab freymvorklarsiz ishlaydi:
1. `index.html` faylini istalgan zamonaviy veb-brauzerda oching.
2. Yoki mahalliy server orqali:
```bash
npx serve .
```

## Mualliflik va Litsenziya
FrontCraft Pro Jamoasi. MIT Litsenziyasi asosida taqdim etiladi.
